HW4

Q1.
11 terms in the equation. Each term representing the attribute that was factored in the computation. 
The columns not included (INDUS and AGE) in the calculation have a negligible impact and are not considered.
Correlation coeeficient is 0.84 is high meaning our equation is likely to produce a reasonable assumption 
based on a new input value and we can reasonably predict the MEDV value. 

Y = -0.1084 * CRIM +
      0.0458 * ZN +
      2.7187 * CHAS=1 +
    -17.376  * NOX +
      3.8016 * RM +
     -1.4927 * DIS +
      0.2996 * RAD +
     -0.0118 * TAX +
     -0.9465 * PTRATIO +
      0.0093 * B +
     -0.5226 * LSTAT +
     36.3411

Q2
Y = -0.8249 * sex=I +
     0.0577 * sex=M +
    -0.4583 * length +
     11.0751 * diameter +
     10.7615 * height +
     8.9754 * whole weight +
    -19.7869 * shucked_weight +
    -10.5818 * viscera_weight +
     8.7418 * shell weight +
     3.8946

Q3
Y = -11.933 * Length + 
     25.766 * Diameter +
     20.358 * Height + 
     2.836